import pg from 'pg';

const { Client } = pg;
const client = new Client({
  connectionString: 'postgresql://postgres:postgres@127.0.0.1:54322/postgres'
});

async function main() {
  try {
    await client.connect();
    
    // 1. Get list of tables
    const tablesRes = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' AND table_type = 'BASE TABLE'
    `);
    console.log('--- DATABASE TABLES ---');
    console.log(tablesRes.rows.map(r => r.table_name).join(', '));
    console.log();

    // 2. Count rows in main tables
    const counts = {};
    for (const row of tablesRes.rows) {
      const t = row.table_name;
      try {
        const countRes = await client.query(`SELECT COUNT(*) FROM "${t}"`);
        counts[t] = countRes.rows[0].count;
      } catch (err) {
        counts[t] = `Error: ${err.message}`;
      }
    }
    console.log('--- ROW COUNTS ---');
    console.log(JSON.stringify(counts, null, 2));
    console.log();

    // 3. Dump Site Settings
    if (counts['site_settings']) {
      const settingsRes = await client.query('SELECT * FROM site_settings');
      console.log('--- SITE SETTINGS ---');
      console.log(JSON.stringify(settingsRes.rows, null, 2));
      console.log();
    }

    // 4. Get latest 5 service tickets
    if (counts['service_tickets']) {
      const ticketsRes = await client.query('SELECT id, ticket_number, customer_name, customer_phone, device_type, status, created_at FROM service_tickets ORDER BY created_at DESC LIMIT 5');
      console.log('--- LATEST 5 SERVICE TICKETS ---');
      console.log(JSON.stringify(ticketsRes.rows, null, 2));
      console.log();
    }

    // 5. Get latest 5 invoices
    if (counts['invoices']) {
      const invoicesRes = await client.query('SELECT id, invoice_no, customer_name, grand_total, balance_due, date, created_at FROM invoices ORDER BY created_at DESC LIMIT 5');
      console.log('--- LATEST 5 INVOICES ---');
      console.log(JSON.stringify(invoicesRes.rows, null, 2));
      console.log();
    }

  } catch (err) {
    console.error('Database connection or query failed:', err);
  } finally {
    await client.end();
  }
}

main();
